Parse VBT from VGA BIOS `C`

[holland@debian intelvbttool]$ make
cc -O2 -g -Wall -Werror -I../../src/commonlib/include -I ../../src/commonlib/bsd/include  intelvbttool.c -o intelvbttool
[holland@debian intelvbttool]$ sudo ./intelvbttool -l -v data.vbt
[sudo] password for holland:
VBTTOOL: Found VBT:
        signature: <$VBT HASWELL        >
        version: 1.00
        VBT size: 0x118d
        VBT checksum: 0x1
        BDB version: 1.89
VBTTOOL: VBT written to data.vbt
[holland@debian intelvbttool]$
