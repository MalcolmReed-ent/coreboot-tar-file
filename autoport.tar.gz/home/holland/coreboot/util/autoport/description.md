Automated porting coreboot to Sandy Bridge/Ivy Bridge/Haswell platforms `Go`
