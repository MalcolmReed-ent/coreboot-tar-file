/* SPDX-License-Identifier: GPL-2.0-only */

#include <southbridge/intel/lynxpoint/pch.h>

/* FIXME: remove this if not needed */
void mainboard_config_superio(void)
{
}
